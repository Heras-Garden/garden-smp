#If the player is in survival, and not wearing Maximum freezing Prot, run freezing effects
execute at @a[gamemode=!creative] if block ~ ~1 ~ water run execute unless entity @p[nbt={equipment:{chest:{components:{"minecraft:enchantments":{"main:freezing_protection":3}}}}}] run execute if biome ~ ~ ~ #minecraft:is_frozen run function main:environmental/freezing_water
